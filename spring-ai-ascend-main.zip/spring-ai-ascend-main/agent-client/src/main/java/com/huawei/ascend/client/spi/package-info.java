/**
 * agent-client SPI — placeholder (skeleton).
 *
 * <p>Reserved for the client-side SDK SPI surface; content lands in a later
 * wave. Today the package exists only so {@code module-metadata.yaml}
 * can declare {@code spi_packages: [com.huawei.ascend.client.spi]} and pass
 * gate Rule 36 ({@code domain_module_has_spi_package}).
 *
 * <p>Authority: ADR-0049, Layer-0 principle P-I.
 */
package com.huawei.ascend.client.spi;
