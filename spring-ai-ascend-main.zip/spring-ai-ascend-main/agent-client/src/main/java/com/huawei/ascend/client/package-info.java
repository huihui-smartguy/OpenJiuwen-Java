/**
 * agent-client — AgentClient SDK skeleton (Edge Access plane).
 *
 * <p>Empty placeholder package. The SDK implementation lands in a later
 * wave. This module exists today so the AgentClient team can
 * land work without conflicting with AgentService / Middleware /
 * AgentBus PRs.
 *
 * <p>Authority: ADR-0049, Layer-0 principle P-I.
 */
package com.huawei.ascend.client;
