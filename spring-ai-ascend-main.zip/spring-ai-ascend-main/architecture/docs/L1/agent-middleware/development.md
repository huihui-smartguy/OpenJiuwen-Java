---
level: L1
view: development
status: template
authority: "ADR-0152 (Uniform L1 per-view mechanism + L0 mounting)"
---

# `agent-middleware` — Development View

<!-- W2-stub: this file is RENDERED at W3 by DevTreeRenderer from agent-middleware/src/main/java/**. Do not hand-edit. -->

```text
agent-middleware/
  src/
    main/
      java/
        com/huawei/ascend/<package-path>/
```
